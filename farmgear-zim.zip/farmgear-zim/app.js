/* FarmGear Zim: hire or buy farm equipment in Zimbabwe.
   Plain HTML/CSS/JS, no build step. Opens straight in SPCK Editor's preview. */
(function () {
  'use strict';

  var $ = function (s) { return document.querySelector(s); };
  var esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var money = function (n) { return '$' + Number(n).toLocaleString('en-US'); };

  var CATS = [
    { id: 'tractor', name: 'Tractors' },
    { id: 'tillage', name: 'Ploughs & planters' },
    { id: 'irrigation', name: 'Irrigation & pumps' },
    { id: 'sprayer', name: 'Sprayers' },
    { id: 'trailer', name: 'Trailers' },
    { id: 'processing', name: 'Shellers & mills' }
  ];
  var TOWNS = ['Harare', 'Bulawayo', 'Mutare', 'Gweru', 'Masvingo', 'Chinhoyi', 'Chiredzi', 'Marondera', 'Bindura', 'Kadoma'];
  var catName = function (id) { var c = CATS.filter(function (x) { return x.id === id; })[0]; return c ? c.name : ''; };

  /* Sample listings. Prices are examples in USD, not real offers. */
  var SAMPLES = [
    { id: 's1', title: 'Massey Ferguson tractor', cat: 'tractor', town: 'Chinhoyi', cond: 'Used, good', hire: 85, buy: 14500,
      specs: [['Power', 'About 75 hp'], ['Drive', '2WD'], ['Hire includes', 'Operator, fuel extra']] },
    { id: 's2', title: 'John Deere 5E tractor', cat: 'tractor', town: 'Harare', cond: 'Used, very good', hire: 95, buy: 28000,
      specs: [['Power', 'About 90 hp'], ['Drive', '4WD'], ['Hire includes', 'Operator']] },
    { id: 's3', title: '3-disc plough', cat: 'tillage', town: 'Gweru', cond: 'Used, good', hire: 25, buy: 900,
      specs: [['Discs', '3'], ['Fits', '70 to 90 hp tractors'], ['Hire per', 'Day, tractor not included']] },
    { id: 's4', title: '4-row maize planter', cat: 'tillage', town: 'Masvingo', cond: 'Used, fair', hire: 40, buy: null,
      specs: [['Rows', '4'], ['Crops', 'Maize, sunflower, beans'], ['Hire per', 'Day']] },
    { id: 's5', title: 'Solar borehole pump kit', cat: 'irrigation', town: 'Bulawayo', cond: 'New', hire: null, buy: 1850,
      specs: [['Includes', 'Pump, panels, controller'], ['Best for', 'Boreholes up to 60 m'], ['Install', 'Available on request']] },
    { id: 's6', title: 'Drip irrigation kit, 1 hectare', cat: 'irrigation', town: 'Chiredzi', cond: 'New', hire: null, buy: 1200,
      specs: [['Covers', '1 hectare'], ['Includes', 'Tape, filters, fittings'], ['Crops', 'Tomatoes, butternut, vegetables']] },
    { id: 's7', title: '16 litre knapsack sprayer', cat: 'sprayer', town: 'Mutare', cond: 'New', hire: null, buy: 35,
      specs: [['Tank', '16 litres'], ['Type', 'Manual lever'], ['Use', 'Herbicide, pesticide, foliar feed']] },
    { id: 's8', title: '400 litre boom sprayer', cat: 'sprayer', town: 'Marondera', cond: 'Used, good', hire: 30, buy: null,
      specs: [['Tank', '400 litres'], ['Boom', '8 m'], ['Hire per', 'Day']] },
    { id: 's9', title: '5 tonne tipper trailer', cat: 'trailer', town: 'Harare', cond: 'Used, good', hire: 60, buy: 4200,
      specs: [['Load', '5 tonnes'], ['Tipping', 'Hydraulic'], ['Hire per', 'Day']] },
    { id: 's10', title: 'Diesel maize sheller', cat: 'processing', town: 'Bindura', cond: 'Used, good', hire: 20, buy: 1100,
      specs: [['Engine', 'Diesel'], ['Output', 'About 1 tonne per hour'], ['Hire per', 'Day']] },
    { id: 's11', title: '3 inch petrol water pump', cat: 'irrigation', town: 'Chiredzi', cond: 'Used, good', hire: 12, buy: 280,
      specs: [['Outlet', '3 inch'], ['Engine', 'Petrol'], ['Hire per', 'Day']] },
    { id: 's12', title: 'Hammer mill', cat: 'processing', town: 'Kadoma', cond: 'Used, fair', hire: 18, buy: 1600,
      specs: [['Use', 'Maize meal, stock feed'], ['Power', 'Electric or tractor PTO'], ['Hire per', 'Day']] }
  ];

  /* ---------- State ---------- */
  var KEY = 'farmgear-zim-v1';
  var blank = { name: '', role: 'Farmer', town: '', phone: '', photo: '' };
  var store = { profile: Object.assign({}, blank), saved: [], mine: [] };
  try {
    var raw = localStorage.getItem(KEY);
    if (raw) {
      var p = JSON.parse(raw);
      store.profile = Object.assign({}, blank, p.profile || {});
      store.saved = Array.isArray(p.saved) ? p.saved : [];
      store.mine = Array.isArray(p.mine) ? p.mine : [];
    }
  } catch (e) { /* storage unavailable: app still works for this visit */ }

  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { /* ignore */ }
  }

  var mode = 'hire', cat = 'all', view = 'browse';
  var all = function () { return store.mine.concat(SAMPLES); };
  var byId = function (id) { return all().filter(function (l) { return l.id === id; })[0]; };

  /* ---------- Icons and avatar ---------- */
  function icon(id, cls) {
    return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 48 48" aria-hidden="true"><use href="#i-' + id + '"/></svg>';
  }
  function initials(name) {
    var parts = name.trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '';
    return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
  }
  function avatarHTML() {
    var pr = store.profile;
    if (pr.photo) return '<img src="' + pr.photo + '" alt="">';
    var ini = initials(pr.name);
    return ini ? esc(ini) : icon('person');
  }
  function paintAvatars() {
    $('#hdrAvatar').innerHTML = avatarHTML();
    $('#bigAvatar').innerHTML = avatarHTML();
  }

  /* ---------- Cards ---------- */
  function card(l, activeMode) {
    var saved = store.saved.indexOf(l.id) > -1;
    var tags = '';
    if (l.mine) tags += '<span class="tag yours">Yours</span>';
    if (l.hire) tags += '<span class="tag hire' + (activeMode === 'hire' ? ' on' : '') + '">Hire ' + money(l.hire) + '/day</span>';
    if (l.buy) tags += '<span class="tag buy' + (activeMode === 'buy' ? ' on' : '') + '">Buy ' + money(l.buy) + '</span>';
    return '<li class="card">' +
      '<button type="button" class="card-main" data-open="' + esc(l.id) + '">' +
        '<span class="thumb">' + icon(l.cat) + '</span>' +
        '<span><h3>' + esc(l.title) + '</h3>' +
        '<span class="meta">' + esc(l.town) + ' · ' + esc(l.cond) + '</span>' +
        '<span class="tags">' + tags + '</span></span>' +
      '</button>' +
      '<button type="button" class="heart" data-save="' + esc(l.id) + '" aria-pressed="' + saved + '" aria-label="' +
        (saved ? 'Remove from saved: ' : 'Save: ') + esc(l.title) + '">' + icon('heart') + '</button>' +
    '</li>';
  }

  function filtered() {
    var q = $('#q').value.trim().toLowerCase();
    var town = $('#town').value;
    return all().filter(function (l) {
      if (!(mode === 'hire' ? l.hire : l.buy)) return false;
      if (cat !== 'all' && l.cat !== cat) return false;
      if (town && l.town !== town) return false;
      if (q && (l.title + ' ' + l.town + ' ' + catName(l.cat)).toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
  }

  function renderChips() {
    var html = '<button type="button" class="chip" data-cat="all" aria-pressed="' + (cat === 'all') + '">All</button>';
    CATS.forEach(function (c) {
      html += '<button type="button" class="chip" data-cat="' + c.id + '" aria-pressed="' + (cat === c.id) + '">' + esc(c.name) + '</button>';
    });
    $('#chips').innerHTML = html;
  }

  function renderBrowse() {
    var rows = filtered();
    $('#list').innerHTML = rows.map(function (l) { return card(l, mode); }).join('');
    $('#empty').hidden = rows.length > 0;
    $('#count').textContent = rows.length + (rows.length === 1 ? ' item' : ' items') + ' to ' + mode;
    document.querySelectorAll('[data-mode]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-mode') === mode));
    });
    renderChips();
  }

  function renderSaved() {
    var rows = all().filter(function (l) { return store.saved.indexOf(l.id) > -1; });
    $('#savedList').innerHTML = rows.map(function (l) { return card(l, null); }).join('');
    $('#savedEmpty').hidden = rows.length > 0;
  }

  function renderProfile() {
    var pr = store.profile;
    $('#pName').value = pr.name;
    $('#pRole').value = pr.role;
    $('#pTown').value = pr.town;
    $('#pPhone').value = pr.phone;
    $('#stSaved').textContent = store.saved.length;
    $('#stMine').textContent = store.mine.length;
    $('#photoDel').hidden = !pr.photo;
    paintAvatars();
  }

  function renderAll() { renderBrowse(); renderSaved(); renderProfile(); }

  /* ---------- Router ---------- */
  var VIEWS = ['browse', 'saved', 'profile'];
  function route() {
    var h = (location.hash || '#browse').slice(1);
    view = VIEWS.indexOf(h) > -1 ? h : 'browse';
    VIEWS.forEach(function (v) { $('#view-' + v).hidden = v !== view; });
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      if (a.getAttribute('data-nav') === view) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
    if (view === 'saved') renderSaved();
    if (view === 'profile') renderProfile();
    window.scrollTo(0, 0);
  }

  /* ---------- Sheet ---------- */
  var lastFocus = null;
  function openSheet(html) {
    lastFocus = document.activeElement;
    $('#sheetBody').innerHTML = html;
    $('#overlay').hidden = false;
    document.body.style.overflow = 'hidden';
    $('#sheetX').focus();
  }
  function closeSheet() {
    $('#overlay').hidden = true;
    document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  var toastTimer;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 2400);
  }

  function openDetail(id) {
    var l = byId(id);
    if (!l) return;
    var prices = '';
    if (l.hire) prices += '<div class="price hire"><span>Hire per day</span><b>' + money(l.hire) + '</b></div>';
    if (l.buy) prices += '<div class="price buy"><span>Buy</span><b>' + money(l.buy) + '</b></div>';
    var specs = (l.specs || []).map(function (s) {
      return '<dt>' + esc(s[0]) + '</dt><dd>' + esc(s[1]) + '</dd>';
    }).join('');
    var want = mode === 'buy' && l.buy ? 'buy' : (l.hire ? 'hire' : 'buy');
    var msg = 'Hi, I saw "' + l.title + '" in ' + l.town + ' on FarmGear Zim. Is it still available to ' + want + '?';
    var wa = 'https://wa.me/?text=' + encodeURIComponent(msg);
    var note = l.mine
      ? '<button type="button" class="btn ghost" data-remove="' + esc(l.id) + '">Remove my listing</button>'
      : '<p class="sheet-note">Sample listing. Price and seller are examples for this preview.</p>';
    openSheet(
      '<span class="thumb">' + icon(l.cat) + '</span>' +
      '<h2>' + esc(l.title) + '</h2>' +
      '<p class="meta">' + esc(catName(l.cat)) + ' · ' + esc(l.town) + ' · ' + esc(l.cond) + '</p>' +
      '<div class="price-row">' + prices + '</div>' +
      (specs ? '<dl>' + specs + '</dl>' : '') +
      '<a class="btn" href="' + wa + '" target="_blank" rel="noopener">' + icon('whatsapp') + 'Message on WhatsApp</a>' +
      note
    );
  }

  function openAdd() {
    var catOpts = CATS.map(function (c) { return '<option value="' + c.id + '">' + esc(c.name) + '</option>'; }).join('');
    var townOpts = TOWNS.map(function (t) {
      return '<option' + (store.profile.town === t ? ' selected' : '') + '>' + esc(t) + '</option>';
    }).join('');
    openSheet(
      '<h2>List equipment</h2>' +
      '<p class="meta">Add a price to hire, to buy, or both.</p>' +
      '<form class="form" id="addForm" autocomplete="off" style="margin-top:14px">' +
        '<label class="field"><span>What is it?</span><input id="aTitle" type="text" required placeholder="e.g. Ferguson tractor"></label>' +
        '<label class="field"><span>Type</span><select id="aCat">' + catOpts + '</select></label>' +
        '<label class="field"><span>Town</span><select id="aTown">' + townOpts + '</select></label>' +
        '<label class="field"><span>Condition</span><select id="aCond"><option>New</option><option>Used, very good</option><option selected>Used, good</option><option>Used, fair</option></select></label>' +
        '<label class="field"><span>Hire price per day (USD)</span><input id="aHire" type="text" inputmode="numeric" placeholder="Leave empty if not for hire"></label>' +
        '<label class="field"><span>Selling price (USD)</span><input id="aBuy" type="text" inputmode="numeric" placeholder="Leave empty if not for sale"></label>' +
        '<p class="meta" id="aErr" role="alert"></p>' +
        '<button type="submit" class="btn alt">Add to my listings</button>' +
      '</form>' +
      '<p class="sheet-note">Saved on this device only. Other people will not see it yet.</p>'
    );
    $('#addForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var title = $('#aTitle').value.trim();
      var hire = parseInt($('#aHire').value.replace(/[^\d]/g, ''), 10) || null;
      var buy = parseInt($('#aBuy').value.replace(/[^\d]/g, ''), 10) || null;
      if (!title) { $('#aErr').textContent = 'Enter what the equipment is.'; return; }
      if (!hire && !buy) { $('#aErr').textContent = 'Add a hire price, a selling price, or both.'; return; }
      var l = {
        id: 'u' + Date.now(), mine: true, title: title,
        cat: $('#aCat').value, town: $('#aTown').value, cond: $('#aCond').value,
        hire: hire, buy: buy, specs: [['Listed by', store.profile.name || 'You']]
      };
      store.mine.unshift(l);
      persist();
      mode = hire ? 'hire' : 'buy';
      cat = 'all'; $('#q').value = ''; $('#town').value = '';
      closeSheet();
      renderAll();
      if (location.hash !== '#browse') location.hash = '#browse';
      toast('Listed. Find it first in the list.');
    });
  }

  /* ---------- Photo ---------- */
  function setPhoto(file) {
    if (!file) return;
    var msg = $('#photoMsg');
    var fr = new FileReader();
    fr.onerror = function () { msg.textContent = 'That photo could not be read. Try another one.'; };
    fr.onload = function () {
      var img = new Image();
      img.onerror = function () { msg.textContent = 'That file is not a photo. Pick a JPG or PNG.'; };
      img.onload = function () {
        var S = 256, c = document.createElement('canvas');
        c.width = S; c.height = S;
        var side = Math.min(img.width, img.height);
        c.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
        store.profile.photo = c.toDataURL('image/jpeg', 0.85);
        persist();
        msg.textContent = 'Photo updated.';
        renderProfile();
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  /* ---------- Events ---------- */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-open],[data-save],[data-cat],[data-mode],[data-remove]');
    if (!t) return;
    if (t.hasAttribute('data-save')) {
      var id = t.getAttribute('data-save');
      var i = store.saved.indexOf(id);
      if (i > -1) store.saved.splice(i, 1); else store.saved.push(id);
      persist(); renderBrowse(); renderSaved(); renderProfile();
    } else if (t.hasAttribute('data-open')) {
      openDetail(t.getAttribute('data-open'));
    } else if (t.hasAttribute('data-cat')) {
      cat = t.getAttribute('data-cat'); renderBrowse();
    } else if (t.hasAttribute('data-mode')) {
      mode = t.getAttribute('data-mode'); renderBrowse();
    } else if (t.hasAttribute('data-remove')) {
      var rid = t.getAttribute('data-remove');
      store.mine = store.mine.filter(function (l) { return l.id !== rid; });
      store.saved = store.saved.filter(function (s) { return s !== rid; });
      persist(); closeSheet(); renderAll(); toast('Listing removed.');
    }
  });

  $('#q').addEventListener('input', renderBrowse);
  $('#town').addEventListener('change', renderBrowse);
  $('#addBtn').addEventListener('click', openAdd);
  $('#addBtn2').addEventListener('click', openAdd);
  $('#sheetX').addEventListener('click', closeSheet);
  $('#overlay').addEventListener('click', function (e) { if (e.target === this) closeSheet(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#overlay').hidden) closeSheet(); });

  $('#photoIn').addEventListener('change', function () { setPhoto(this.files && this.files[0]); this.value = ''; });
  $('#photoDel').addEventListener('click', function () {
    store.profile.photo = ''; persist(); $('#photoMsg').textContent = 'Photo removed.'; renderProfile();
  });
  function bindField(id, key) {
    $(id).addEventListener('input', function () {
      store.profile[key] = this.value; persist(); paintAvatars();
    });
  }
  bindField('#pName', 'name'); bindField('#pRole', 'role'); bindField('#pTown', 'town'); bindField('#pPhone', 'phone');

  window.addEventListener('hashchange', route);

  /* ---------- Init ---------- */
  function fillTowns() {
    $('#town').innerHTML = '<option value="">All towns</option>' + TOWNS.map(function (t) { return '<option>' + t + '</option>'; }).join('');
    $('#pTown').innerHTML = '<option value="">Choose your town</option>' + TOWNS.map(function (t) { return '<option>' + t + '</option>'; }).join('');
  }
  fillTowns();
  renderAll();
  route();

  /* ---------- Splash ---------- */
  var splash = $('#splash');
  var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var done = false;
  function endSplash() {
    if (done) return;
    done = true;
    splash.classList.add('out');
    setTimeout(function () { splash.remove(); }, 600);
  }
  splash.addEventListener('click', endSplash);
  setTimeout(endSplash, reduced ? 1000 : 2900);
})();
